

function Validator () {
    let Username = document.getElementById('userName').value;

    let UserAge = document.getElementById('age').value;

    document.getElementById('userName').textContent = Username;

    console.log(Username);
    console.log(UserAge);

}